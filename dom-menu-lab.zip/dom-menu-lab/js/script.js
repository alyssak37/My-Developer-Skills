
const mainEl = document.querySelector('main');
console.log(mainEl)

mainEl.style.backgroundColor = 'var(--main-bg)';

mainEl.innerHTML = '<h1>SEI Rocks!</h1>'; 

const topMenuEl = document.querySelector('#top-menu');
console.log(topMenuEl)

topMenuEl.style.backgroundColor = 'var(--top-menu-bg)';